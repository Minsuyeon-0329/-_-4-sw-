GUI_part파일은 Android Studio에서 열 수 있습니다.
eyetracking파일은 Pycharm에서 열 수 있고 코드를 실행시키기 위해서는 Dlib와 opencv를 따로 다운받으셔야 합니다.