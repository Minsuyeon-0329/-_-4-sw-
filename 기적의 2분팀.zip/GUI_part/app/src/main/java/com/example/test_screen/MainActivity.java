package com.example.test_screen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private long backBtnTime = 0;
    private Button calibration;
    private Button start;
    private ImageButton settings;
    private ImageButton how;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //intent설정해주고 sound_or_vibration에서 putExtra로 넣은 milestone값 받아오기


        //이러면 이제 값이 있다면 받아왔으니깐 이걸 또 넘겨주면 됩니다.


        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();


        calibration=findViewById(R.id.calibration);
        calibration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, Calibration_screen.class);
                startActivity(intent); // 보정 액티비티로 이동
            }
        });


        start=findViewById(R.id.start);
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent settings_intent = getIntent();

                if(settings_intent.hasExtra("comeback")){
                    int milestone = settings_intent.getIntExtra("comeback",0);
                    Intent main_intent = new Intent(MainActivity.this, Game_screen.class);
                    main_intent.putExtra("milestone",milestone);//이리로 드가야 하는데?
                    startActivity(main_intent); // 게임 액티비티로 이동
                }else {
                    Intent main_intent = new Intent(MainActivity.this, Game_screen.class);
                    main_intent.putExtra("milestone",0);// 소리 진동 설정 안했을 때 초기 값은 소리로
                    startActivity(main_intent); // 게임 액티비티로 이동
                }

            }
        });


        settings = findViewById(R.id.set);
        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, Settings.class);
                startActivity(intent); // 게임 액티비티로 이동
            }
        });


        how = findViewById(R.id.How);
        how.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, How_to_Play.class);
                startActivity(intent); // 게임 설명으로 이동
            }
        });
    }

    @Override
    public void onBackPressed(){
        long curTime = System.currentTimeMillis();
        long gapTime = curTime - backBtnTime;

        if (0 <= gapTime && 2000 >= gapTime){
            super.onBackPressed();
        }
        else {
            backBtnTime = curTime;
            Toast.makeText(this,"한번 더 누르면 종료됩니다.",Toast.LENGTH_SHORT).show();
        }

    }
}