package com.example.test_screen;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Game_screen extends AppCompatActivity implements Button.OnClickListener{

    Button StraightLine;
    Button Rotational;
    Button eighteight;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_screen);

        Intent game_intent = getIntent();

        if(game_intent.hasExtra("milestone")){
            int milestone = game_intent.getIntExtra("milestone",0);
            TextView tx = (TextView)findViewById(R.id.textView1);
            tx.setText(String.valueOf(milestone));
        }
        //이제 이 milestone값을 이용해서 feedback에 만든 그거를 같이 이용하면 됩니다.



        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();

        StraightLine=(Button)findViewById(R.id.StraightLine);
        StraightLine.setOnClickListener(this);
        Rotational=(Button)findViewById(R.id.Rotational);
        Rotational.setOnClickListener(this);
        eighteight=(Button)findViewById(R.id.eighteight);
        eighteight.setOnClickListener(this);
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    public void onClick(View v) {

        //버튼 3개 중
        //만약 버튼 1을 클릭했다면
        //만약 버튼 2를 클릭했다면...
        //if 문과 switch-case

        switch (v.getId()){
            case R.id.StraightLine: Intent intent1 = new Intent(Game_screen.this, Straight.class); startActivity(intent1);break;
            case R.id.Rotational: Intent intent2 = new Intent(Game_screen.this, Rotational.class); startActivity(intent2);break;
            case R.id.eighteight: Intent intent3 = new Intent(Game_screen.this, eighteight.class); startActivity(intent3);break;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
    }


}