package com.example.test_screen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

public class sound_or_vibration extends AppCompatActivity {


    private Button btn_sound;
    private Button btn_vibration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sound_or_vibration);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();

        btn_sound = findViewById(R.id.btn_sound);
        btn_vibration = findViewById(R.id.btn_vibration);

        btn_sound.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int milestone = 0;
                Intent btn_intent = new Intent(sound_or_vibration.this,MainActivity.class);
                btn_intent.putExtra("comeback",milestone);
                btn_intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                // 호출하는 activity 가 스택에 있을 경우, 해당 activity 를 최상위로 올리면서 그 위에 있던 activity 들을 모두 삭제.
                // 뒤로가기 눌러서 현재 액티비티 종료하고 백스택 불러오기기                /
                startActivity(btn_intent);
                finish();
                Toast toast1 = Toast.makeText(getApplicationContext(),"소리로 설정되었습니다.",Toast.LENGTH_SHORT);
                toast1.show();

            }

        });
        btn_vibration = findViewById(R.id.btn_vibration);
        btn_vibration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int milestone = 1;
                Intent btn_intent = new Intent(sound_or_vibration.this, MainActivity.class);
                btn_intent.putExtra("comeback", milestone);//milestone 값 담아주기
                btn_intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(btn_intent);//결과 값 설정
                finish();

                Toast toast2 = Toast.makeText(getApplicationContext(),"진동으로 설정되었습니다.",Toast.LENGTH_SHORT);
                toast2.show();
            }
        });

    }
}