package com.example.test_screen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

public class Settings extends AppCompatActivity {

    private Button push_alarm_setting;
    private Button sound_or_vibration;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);




        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();

        push_alarm_setting = findViewById(R.id.push_alarm_setting);
        push_alarm_setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Settings.this, Push_Alarm.class);
                startActivity(intent);
            }
        });

        sound_or_vibration = findViewById(R.id.sound_or_vibration);
        sound_or_vibration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Settings.this, sound_or_vibration.class);
                startActivity(intent);
            }
        });

    }
}